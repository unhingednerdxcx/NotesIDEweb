python -m venv .venv
source .venv/bin/activate
pip install -r "$(dirname "$0")/req.txt"
