#!/bin/bash

# 1. Get the directory where this script is located
SCRIPT_DIR="$( cd "$( dirname "$0" )" && pwd )"

# 2. Define source and destination paths
SOURCE_DIR="$SCRIPT_DIR/APPDATA_NOTESIDE"
DEST_DIR="$HOME/APPDATA_NOTESIDE"

# 3. Check if the source folder actually exists
if [ ! -d "$SOURCE_DIR" ]; then
    echo "Error: Directory 'APPDATA_NOTESIDE' not found in: $SCRIPT_DIR"
    exit 1
fi

# 4. Move the folder
echo "Moving $SOURCE_DIR to $DEST_DIR..."
mv "$SOURCE_DIR" "$DEST_DIR"

# 5. Check if the move was successful
if [ $? -eq 0 ]; then
    echo "Success! Data moved to home directory."
else
    echo "Error: Failed to move directory."
    exit 1
fi
