import os
import shutil

DEST = r"C:\AppData-Noteside"

os.makedirs(DEST, exist_ok=True)
cwd = os.getcwd()

# move single files
for f in ["notes.txt"]:
    src = os.path.join(cwd, f)
    if os.path.exists(src):
        shutil.move(src, os.path.join(DEST, f))

# move folders
for folder in ["Notes", "Dict", "data"]:
    src = os.path.join(cwd, folder)
    if os.path.exists(src):
        shutil.move(src, os.path.join(DEST, folder))

print("Noteside installer move complete.")
