import os
import shutil

# Destination: C:\Users\<user>\NotesIDE-APPDATA
DEST_ROOT = os.path.join(os.path.expanduser('~'))
os.makedirs(DEST_ROOT, exist_ok=True)

# Directory where THIS python file lives (important for PyInstaller too)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Folder next to this file
SRC_FOLDER = os.path.join(BASE_DIR, 'APPDATA_NOTESIDE')

# Final destination path
DEST_FOLDER = os.path.join(DEST_ROOT, 'APPDATA_NOTESIDE')

if os.path.exists(SRC_FOLDER):
    # Remove old copy if it already exists
    if os.path.exists(DEST_FOLDER):
        shutil.rmtree(DEST_FOLDER)

    shutil.move(SRC_FOLDER, DEST_ROOT)
    print("APPDATA_NOTESIDE moved successfully.")
else:
    print("APPDATA_NOTESIDE folder not found.")

print("NotesIDE installer move complete.")
