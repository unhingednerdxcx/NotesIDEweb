#!/bin/sh

# get directory where this script lives
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# destination
DEST="$HOME/Library/Caches/NotesIDE"

# create destination
mkdir -p "$DEST"

# move the folder
mv "$SCRIPT_DIR/APPDATA_NOTESIDE" "$DEST/"
